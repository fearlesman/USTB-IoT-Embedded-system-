#ifndef __USARTDMA_H
#define	__USARTDMA_H


#include "stm32f10x.h"
#include <stdio.h>

// ??1:?????
#define USART_TX_DMA_CHANNEL    DMA1_Channel4
#define USART_TX_DMA_CLK        RCC_AHBPeriph_DMA1
#define USART_TX_DMA_FLAG_TC    DMA1_FLAG_TC4

// ??2:??????
uint8_t BuffercmpByte(const uint8_t* pBuffer, const uint8_t* pBuffer1, uint16_t BufferLength);
#define SENDBUFF_SIZE           128                 // 32?uint32_t = 128??
extern uint8_t SendBuff[SENDBUFF_SIZE];              // ?bsp_usart_dma.c???
#define BUFFER_SIZE_BYTES (BUFFER_SIZE * 4)  // 128 bytes
// ���ڹ��������궨��
#define  DEBUG_USARTx                   USART1
#define  DEBUG_USART_CLK                RCC_APB2Periph_USART1
#define  DEBUG_USART_APBxClkCmd         RCC_APB2PeriphClockCmd
#define  DEBUG_USART_BAUDRATE           115200

// USART GPIO ���ź궨��
#define  DEBUG_USART_GPIO_CLK           (RCC_APB2Periph_GPIOA)
#define  DEBUG_USART_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
    
#define  DEBUG_USART_TX_GPIO_PORT       GPIOA   
#define  DEBUG_USART_TX_GPIO_PIN        GPIO_Pin_9
#define  DEBUG_USART_RX_GPIO_PORT       GPIOA
#define  DEBUG_USART_RX_GPIO_PIN        GPIO_Pin_10

// ���ڶ�Ӧ��DMA����ͨ��
#define  USART_TX_DMA_CHANNEL     DMA1_Channel4
// ����Ĵ�����ַ
#define  USART_DR_ADDRESS        (USART1_BASE+0x04)
// һ�η��͵�������
#define  SENDBUFF_SIZE            32*4


void USART_Config(void);
void USARTx_DMA_Config(void);

#endif /* __USARTDMA_H */
