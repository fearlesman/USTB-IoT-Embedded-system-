/**
  ******************************************************************************
  * @file    main.c
  * @version V1.0
  * @date    2024-xx-xx
  * @brief   ADC����
  ******************************************************************************
  */ 
 
 
#include "stm32f10x.h"
#include "bsp_usart.h"
#include "bsp_adc.h"


extern __IO uint16_t ADC_ConvertedValue[NOFCHANEL];

// �ֲ����������ڱ���ת�������ĵ�ѹֵ 	 
float ADC_ConvertedValueLocal[NOFCHANEL];        

// ������ʱ
void Delay(__IO uint32_t nCount)
{
  for(; nCount != 0; nCount--);
} 

/**
  * @brief  ������
  * @param  ��
  * @retval ��
  */
int main(void)
{	
  /*��ʼ��USART ����ģʽΪ 115200 8-N-1���жϽ���*/
  USART_Config();
	printf("ADC-��ͨ��-DMA��ȡ����\n\n\n\n");
	
	ADCx_Init();

    while (1)
    {    
        /*
         * ????:
         * 1. ?12?ADC????????
         * 2. ??:?? = (ADC?/4095) * 3.3V
         * 3. ????????
         */
        ADC_ConvertedValueLocal[0] = (float)ADC_ConvertedValue[0] / 4095.0 * 3.3;  // PC0
        ADC_ConvertedValueLocal[1] = (float)ADC_ConvertedValue[1] / 4095.0 * 3.3;  // ??:PC1
        
        printf("\r\n===== ADC Conversion Results =====");
        printf("\r\n CH0(PC0) ADC Value = 0x%04X, Voltage = %.3f V", 
               ADC_ConvertedValue[0], ADC_ConvertedValueLocal[0]);
        printf("\r\n CH1(PC1) ADC Value = 0x%04X, Voltage = %.3f V", 
               ADC_ConvertedValue[1], ADC_ConvertedValueLocal[1]);
        printf("\r\n==================================\r\n\r\n");
			
        // ???1?(????????)
        Delay(0xffffee);         
    }
}

/*********************************************END OF FILE**********************/
