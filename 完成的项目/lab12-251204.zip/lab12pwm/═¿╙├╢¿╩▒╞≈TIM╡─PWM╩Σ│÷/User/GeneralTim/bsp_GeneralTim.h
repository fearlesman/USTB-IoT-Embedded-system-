#ifndef __BSP_GENERALTIM_H
#define __BSP_GENERALTIM_H

#include "stm32f10x.h"

// ???????
#define GENERAL_TIM                  TIM3
#define GENERAL_TIM_APBxClock_FUN    RCC_APB1PeriphClockCmd
#define GENERAL_TIM_CLK              RCC_APB1Periph_TIM3
#define GENERAL_TIM_Period           999   // ???,0-999 = 1000????
#define GENERAL_TIM_Prescaler        71    // ????,72MHz/(71+1)=1MHz

// ?????????
// ??:????????,TIM3?????:
// CH2 -> PB5 (??)
// CH3 -> PB0 (??) 
// CH4 -> PB1 (??)
#define GENERAL_TIM_CH2_PIN          GPIO_Pin_5
#define GENERAL_TIM_CH2_PORT         GPIOB
#define GENERAL_TIM_CH2_GPIO_CLK     RCC_APB2Periph_GPIOB

#define GENERAL_TIM_CH3_PIN          GPIO_Pin_0
#define GENERAL_TIM_CH3_PORT         GPIOB
#define GENERAL_TIM_CH3_GPIO_CLK     RCC_APB2Periph_GPIOB

#define GENERAL_TIM_CH4_PIN          GPIO_Pin_1
#define GENERAL_TIM_CH4_PORT         GPIOB
#define GENERAL_TIM_CH4_GPIO_CLK     RCC_APB2Periph_GPIOB

void GENERAL_TIM_Init();
void GENERAL_TIM_Update(uint16_t chval, uint8_t channel);
void TIM_Stop(void);

#endif /* __BSP_GENERALTIM_H */