/**
  ******************************************************************************
  * @file    main.c
  * @brief   Stop Mode Example
  ******************************************************************************
  */
#include "stm32f10x.h"
#include "./led/bsp_led.h"
#include "./usart/bsp_usart.h"
#include "./Key/bsp_exti.h"
#include "./TimBase/bsp_TiMbase.h"
#include "stm32f10x_pwr.h"  // Added for PWR control

static void Delay(__IO u32 nCount);

/**
  * @brief  Main Function
  * @param  None
  * @retval None
  */
int main(void)
{ 
    LED_GPIO_Config();    
    USART_Config();        // Initialize USART1
    EXTI_Key_Config();     // Configure button as EXTI interrupt source

    printf("\r\n 1. In this program:\r\n");
    printf("   - Green LED: STM32 normal operation\r\n");
    printf("   - Red LED: Stop mode (deep sleep)\r\n");
    printf("   - Blue LED: Just woken up from stop mode\r\n");
    printf("\r\n 2. System will automatically enter stop mode after running.\r\n");
    printf("   - Only button interrupt can wake up from stop mode\r\n");
    printf("   - Timer interrupt CANNOT wake up from stop mode\r\n");
    
    while(1)
    {   
        /********* Normal Operation Task ***************************/
        printf("\r\n STM32 normal operation - Green LED ON\r\n");
        LED_GREEN;    
        Delay(0x3FFFFF);
        
        /***** Prepare to enter stop mode ***********/        
        printf("\r\n Entering STOP MODE (deep sleep)...\r\n");
        printf("   Press USER button to wake up\r\n");
        printf("   Timer interrupt will NOT wake up the system\r\n");

        // Red LED indicates stop mode entry
        LED_RED;
        
        // Enable PWR clock for stop mode configuration
        RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
        
        // Enter stop mode with low power regulator
        PWR_EnterSTOPMode(PWR_Regulator_LowPower, PWR_STOPEntry_WFI);
        
        // IMPORTANT: Reconfigure system clock after wake-up
        SystemInit();  // Reset to 72MHz system clock
        
        // Reinitialize USART due to clock changes
        USART_Config(); 
        
        /*** Woken up - Blue LED indicates wake-up state ***/
        LED_BLUE;    
        printf("\r\n WOKEN UP from stop mode - Blue LED ON\r\n");
        Delay(0x1FFFFF);        
            
        printf("\r\n Exiting stop mode...\r\n");
        // Continue main loop
    }
}

static void Delay(__IO uint32_t nCount)     // Simple delay function
{
    for(; nCount != 0; nCount--);
}

/*********************************************END OF FILE**********************/