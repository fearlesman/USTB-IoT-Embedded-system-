// mystm32reg.h

#ifndef __MYSTM32REG_H
#define __MYSTM32REG_H

#define PERIPH_BASE               ((unsigned int)0x40000000)
#define APB1PERIPH_BASE           PERIPH_BASE
#define APB2PERIPH_BASE           (PERIPH_BASE + 0x10000)
#define AHBPERIPH_BASE            (PERIPH_BASE + 0x20000)

// RCC
#define RCC_BASE                  (AHBPERIPH_BASE + 0x1000)
#define RCC_APB2ENR               (*(volatile unsigned int*)(RCC_BASE + 0x18))

// GPIOA
#define GPIOA_BASE                (APB2PERIPH_BASE + 0x0800)
#define GPIOA_CRL                 (*(volatile unsigned int*)(GPIOA_BASE + 0x00))
#define GPIOA_IDR                 (*(volatile unsigned int*)(GPIOA_BASE + 0x08))

// GPIOB
#define GPIOB_BASE                (APB2PERIPH_BASE + 0x0C00)
#define GPIOB_CRL                 (*(volatile unsigned int*)(GPIOB_BASE + 0x00))
#define GPIOB_ODR                 (*(volatile unsigned int*)(GPIOB_BASE + 0x0C))

#endif /* __MYSTM32REG_H */