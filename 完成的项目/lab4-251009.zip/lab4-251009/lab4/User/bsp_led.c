#include "bsp_led.h"

void LED_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 1. ?? GPIOE ??(??? LED ? PE5~7)
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);
    
    // 2. ?? PE5~PE7 ?????
    GPIO_InitStructure.GPIO_Pin = R_LED_PIN | G_LED_PIN | B_LED_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;      // ????
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;     // 50MHz ??
	
    GPIO_Init(LED_PORT, &GPIO_InitStructure);
    
    // 3. ????(?????,???????)
    GPIO_SetBits(LED_PORT, R_LED_PIN | G_LED_PIN | B_LED_PIN);
}

// LED ????(?????)
void R_LED_ON(void)  { GPIO_ResetBits(LED_PORT, R_LED_PIN); }
void R_LED_OFF(void) { GPIO_SetBits(LED_PORT, R_LED_PIN); }
void G_LED_ON(void)  { GPIO_ResetBits(LED_PORT, G_LED_PIN); }
void G_LED_OFF(void) { GPIO_SetBits(LED_PORT, G_LED_PIN); }
void B_LED_ON(void)  { GPIO_ResetBits(LED_PORT, B_LED_PIN); }
void B_LED_OFF(void) { GPIO_SetBits(LED_PORT, B_LED_PIN); }

// ??????
void LED_Delay(__IO uint32_t nCount)
{
    for(; nCount != 0; nCount--);
}