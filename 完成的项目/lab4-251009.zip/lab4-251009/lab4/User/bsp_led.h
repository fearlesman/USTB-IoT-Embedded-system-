#ifndef __BSP_LED_H
#define __BSP_LED_H

#include "stm32f10x.h"

// ??????? LED ????
#define R_LED_PIN    GPIO_Pin_5
#define G_LED_PIN    GPIO_Pin_6
#define B_LED_PIN    GPIO_Pin_7
#define LED_PORT     GPIOE   // ??:? GPIOE!

void LED_Init(void);
void R_LED_ON(void);
void R_LED_OFF(void);
void G_LED_ON(void);
void G_LED_OFF(void);
void B_LED_ON(void);
void B_LED_OFF(void);
void LED_Delay(__IO uint32_t nCount);

#endif