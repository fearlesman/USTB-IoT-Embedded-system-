#include "stm32f10x.h"
#include "bsp_led.h"

int main(void)
{
    LED_Init();  // ??? LED
    
    while (1)
    {
        R_LED_ON();   LED_Delay(0x0FFFFF);  // ???
        R_LED_OFF();
        
        G_LED_ON();   LED_Delay(0x0FFFFF);  // ???
        G_LED_OFF();
        
        B_LED_ON();   LED_Delay(0x0FFFFF);  // ???
        B_LED_OFF();
    }
}