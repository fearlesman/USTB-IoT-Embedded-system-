#ifndef __BSP_EXTI_H
#define __BSP_EXTI_H

#include "stm32f10x.h"

void EXTI_Key_Config(void); 

#endif /* __BSP_EXTI_H */